#
#<?php die('Forbidden.'); ?>
#Date: 2015-08-19 06:27:05 UTC
#Software: Joomla Platform 13.1.0 Stable [ Curiosity ] 24-Apr-2013 00:00 GMT

#Fields: datetime	priority clientip	category	message
2015-08-19T06:27:05+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2015-08-19T09:31:35+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2015-08-19T09:31:46+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2015-08-19T09:32:04+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2015-08-19T09:32:19+00:00	INFO 127.0.0.1	joomlafailure	Username and password do not match or you do not have an account yet.
2015-08-27T09:23:13+00:00	INFO 127.0.0.1	joomlafailure	Empty password not allowed.
