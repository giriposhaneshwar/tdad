<?php
/*
# ------------------------------------------------------------------------
# Extensions for Joomla 2.5.x - Joomla 3.x
# ------------------------------------------------------------------------
# Copyright (C) 2011-2013 Ext-Joom.com. All Rights Reserved.
# @license - PHP files are GNU/GPL V2.
# Author: Ext-Joom.com
# Websites:  http://www.ext-joom.com 
# Date modified: 04/08/2013 - 13:00
# ------------------------------------------------------------------------
*/

// no direct access
defined('_JEXEC') or die;
?>
<?php echo $html; ?>
<?php /*?><div class="mod_ext_custom <?php echo $moduleclass_sfx ?>">
	<?php echo $html; ?>
	<div style="clear:both;"></div>
</div><?php */?>