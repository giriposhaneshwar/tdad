<div class="custom-dialog likepop">
    <div class="vdetail-title clearfix">
            <a href="javascript:void(0)" class="dialog-close close-popup"><i class="sprite-img close-pop"></i></a>
        <div class="dialog-title clearfix">
            <div class="pop-name-btn clearfix">
            	<p class="mb10 sub-hea">Equity Diversified Funds</p>
            	<h5 class="pro-name pop-name"><a href="javascript:void(0)">Axis Equity Fund</a></h5>
                <a href="javascript:void(0)" class="primary-btn buy-rgt">Invest</a>
            </div>
            <div class="mt10">
                <div class="clearfix mt5">
                <div class="mar-val-inper pop-left-price mutual-hea-left">
                <p class="mutual-growth">NAV (Growth Option)</p>
                    <h2 class="mar-val">30.16 <span><i class="sprite-img market-val-inc"></i>37.46 (0.22%)</span></h2>
                </div>
                <div class="mutual-years">
                	<ul class="mutual-pop-33 clearfix">
                        <li>
                            <small>1Y Return</small>
                            <h4 class="pro-val-normal">7.25%</h4>
                        </li>
                        <li class="border">
                            <small>3Y Return</small>
                            <h4 class="pro-val-normal">10.05%</h4>
                        </li>
                        <li class="border">
                            <small>5Y Return</small>
                            <h4 class="pro-val-normal">13.25%</h4>
                        </li>
                    </ul>
                </div>
                </div>                           
            </div>
        </div>
    </div>
    <div class="popup-insight">
        <div class="dialog-content">
        	<h4>Fund Objective</h4>
            <p class="mutual-con">To achieve long term capital appreciation by investing in a diversified portfolio predominantly consisting of equity and equity related securities including derivatives</p>	
        	<div class="graph-twoparts">
                        	 <div class="out-graph">
							<div class="trading-two-pop">
                            	<ul class="trading-popup-list mutual-list">
                                	<li>
                                    	<small>Lauched Date</small>
                                        <h4 class="pro-val-normal">06-JUL-2015</h4>
                                    </li>
                                    <li class="border-left">
                                    	<small>Benchmark</small>
                                        <h4 class="pro-val-normal">CNX Nifty INdex</h4>
                                    </li>
                                    <li>
                                    	<small>Fund Manager</small>
                                        <h4 class="pro-val-normal">06-JUL-2015</h4>
                                    </li>
                                    <li class="border-left">
                                    	<small>Corpus</small>
                                        <h4 class="pro-val-normal">1783 Cr.</h4>
                                    </li>
                                    <li>
                                    	<small>Value Research Rating</small>
                                        <p class="mt5">
                                        <i class="sprite-img star-fill"></i>
                                        <i class="sprite-img star-fill"></i>
                                        <i class="sprite-img star-fill"></i>
                                        <i class="sprite-img star-unfill"></i>
                                        <i class="sprite-img star-unfill"></i>
                                    </p>
                                    </li>
                                     <li class="border-left">
                                    	<small>Minimum Investment</small>
                                        <h4 class="pro-val-normal">5000</h4>
                                    </li>
                                </ul>
                            </div>      
                            </div>                  
                           <div class="target-val">	
                            <p class="analysis-box-hea">Style Box Analysis</p>
                            <ul class="any-box-list">
                            	<li>
                                	<span class="analysis-box ansis-box-fild"></span>
                                    <span class="analysis-box"></span>
                                    <span class="analysis-box"></span>
                                    <span class="anly-sis-cap">Large Cap</span>
                                </li>
                                <li>
                                	<span class="analysis-box"></span>
                                    <span class="analysis-box"></span>
                                    <span class="analysis-box"></span>
                                    <span class="anly-sis-cap">Mid Cap</span>
                                </li>
                                <li>
                                	<span class="analysis-box"></span>
                                    <span class="analysis-box"></span>
                                    <span class="analysis-box"></span>
                                    <span class="anly-sis-cap">Small Cap</span>
                                </li>
                                <li class="indication">
                                    <span class="anly-sis-cap grow-op">Growth</span>
                                    <span class="anly-sis-cap grow-op">Blend</span>
                                    <span class="anly-sis-cap grow-op">Value</span>
                                </li>
                            </ul>
                           </div>
                       </div>
        </div>
    </div>


</div>
<script>
$(".pop-pack").dialog({
		position: { my: "center", at: "center", of: window,collision: 'fit' }
    });
</script>