<div class="breadcrumb-sec dis-none">
            <div class="bredcrumb clearfix">
                <p class="main-item"><i class="menu-icon-small menu11-small"></i><span>Research Reports</span></p>
                <ul class="researchmenu clearfix">
             <li ><a  data-type="overview" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchreportsoverview'); ?>">Overview</a></li>
             <li><a  data-type="investreports" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchreportsfundamentalreports'); ?>">Invest Reports</a></li>
            <li><a  data-type="reportstraders" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchreportstechnicalreports'); ?>">Reports Traders</a></li>
            <li><a  data-type="mutualfundreports" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchreportsmutualfundreports'); ?>">Mutual Fund Reports</a></li>
            <li><a  data-type="sectoreconomyotherreports" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchreportssectoreconomyothers'); ?>">Sector Economy Other Reports</a></li>
                </ul>
            </div>
        </div>
    