<div class="breadcrumb-sec dis-none">
            <div class="bredcrumb clearfix">
                <p class="main-item"><i class="menu-icon-small menu11-small"></i><span>Research Calls</span></p>
                <ul class="researchmenu clearfix">
             <li ><a  data-type="overview" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchcallsoverview'); ?>">Overview</a></li>
             <li><a data-type="premiumideas" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchcallspremiumideas'); ?>">Premium Ideas</a></li>
            <li><a data-type="investmentideas" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchcallsinvestmentidea'); ?>">Investment Ideas</a></li>
            <li><a  data-type="tradingideas" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchtradingideas'); ?>">Trading Ideas</a></li>
            <li><a data-type="derivativestrategies" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchcallsderivative'); ?>">Derivative Strategies</a></li>
            <li><a data-type="mutualfundideas" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchcallsmutualfundideas'); ?>">Mutual Fund Ideas</a></li>
             <li><a data-type="sipideas" data-noremove="1" href="<?php echo JRoute::_('index.php?option=com_insights&view=researchcallssipideas'); ?>">SIP Ideas</a></li>
                </ul>
            </div>
        </div>