$(document).ready(function(){
  $('.awardItems ul').bxSlider({
  	minSlides: 1,
	maxSlides: 3,
	slideWidth: 360,
	slideMargin: 25,
  	responsive: true,
  	controls: true,
  	auto: true
  });
});