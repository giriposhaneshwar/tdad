var srs = [ "jquery-ui.js", 
            "select2.js", 
            "jquery.newsTicker.js", 
            "checkboxradio-min.js", 
            "jquery.sliderTabs.min.js",
            "jquery.bxslider.min.js", 
            "core.js"
            ];