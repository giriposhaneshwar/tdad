function navigation() {
    var a = $(document).width();
    if (a > 995) {
        $(".ui-accordion-header span.ui-icon");
        $(".first-level-menu > li > a").click(function(a) {
            $(".second-level").not($(this).closest("li").find(".second-level")).hide(),

            $(this).closest("li").find(".second-level").slideToggle(),

            $(this).closest("li").siblings().removeClass("active"),

            $(this).closest("li").toggleClass("active"), a.stopImmediatePropagation()
        }),

        $(".second-level-menu > li").click(function() {
            $(this).closest("li").siblings().removeClass("active"),

            $(this).closest("li").addClass("active")
        }),

        $(document).on("click", function(a) {
            var b = $(a.target).closest(".first-level-menu").length;
            b || ($(".second-level").hide(),

                $(".first-level-menu > li").removeClass("active"))
        })
    } else {
        $("ul.accordion").accordion({
            collapsible: !0,
            active: !0,
            heightStyle: "content"
        });
        $(".ui-accordion-icons")
    }
}

function tabslider() {
    $(".slide-tab").sliderTabs({
        mousewheel: !1,
        position: "top",
        transition: "fade",
        tabSlide: 2,
        tabSlideLength: $(document).width() > 995 ? 200 : 160,
        tabHeight: 100
    })
}
$(document).ready(function() {
    function c() {
        var a = [];
        $('input[name="term"]:checked').each(function() {
            a.push($(this).val())
        });
        $(".invest-items-term").text(a) + ""
    }

    function c() {
        var a = [];
        $('input[name="term"]:checked').each(function() {
            a.push($(this).val())
        });
        $(".invest-items-term").text(a) + ""
    }

    function f() {
        $(document).width() <= 995 ? $(".ca-slider").bxSlider({
            minSlides: 1,
            maxSlides: 1,
            infiniteLoop: !0
        }) : $(".ca-slider").bxSlider({
            minSlides: 3,
            maxSlides: 3,
            slideWidth: 315,
            slideMargin: 20,
            infiniteLoop: !0
        }), console.log("Card Lis Count: ", $("ul.ca-slider > li.shadow-panel").length)
    }
    $(document).width();
    $(".header-top-expand-arrow").on("click", function() {
        $(".top-news-snap").toggle(),

        $(".normal-disaply").toggleClass("expansion-hide-data"),

        $(".after-expand").slideToggle(),

        $(".open-arrow").toggleClass("active"),

        $(".header-second-web").toggleClass("header-second-web-top-expansion"),

        $(".breadcrumb-sec").toggleClass("breadcrumb-sec-after-expansion"),

        $(".site-start").toggleClass("site-start-after-expansion"),

        $(".site-start-modules").toggleClass("site-start-modules-after-expansion")
    });
    var b = $(document).width();
    995 > b && $(".header-top-expand-arrow").on("click", function() {
        $(".overlay").toggle(),

        $(".header-top-after-expand").toggle(),

        $(".normal-disaply").toggleClass("expansion-hide-data"),

        $(".top-news-snap,.expansion-divider").toggle(),

        $(".mob-header-top-icon").toggleClass("active"),

        $("body").toggleClass("header-top-overflow")
    }),

    $(".drop-click").on("click", function() {
        var a = $(this).next();
        $(".support-menu").not(a).hide(), a.toggle()
    }),

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".support").length;
        b || ($(".support-menu").hide(),

            $(".drop-click").removeClass("active"))
    }),

    $(".hea-top-drop li a").on("click", function() {
        $(".select-val").html($(this).text()),

        $(".hea-top-drop").hide(),

        $(".drop-click").removeClass("active")
    }),

    $(".country-drop").on("click", function() {
        $(".header-top-country").toggle()
    }),

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".country-drop").length;
        b || $(".header-top-country").hide()
    }),

    $(".header-top-country li a").on("click", function() {
        $(".coun-select-val").html($(this).text()),

        $(".header-top-country").hide()
    }), navigation(),

    $(".responsive-menu").on("click", function() {
        $("body").toggleClass("off"),
        $(".menu-section").show()
    }),

    $('.responsive-menu-course').on('click', function(d){
        d.preventDefault();
        console.log("Responsive Clicked")
    });

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".menu-section,.header-second-mobile, .leftNavHolder, .rightContentHolder").length;
        b || $("body").removeClass("off")
    }),

    $(".pcacs-tabs").on("click", function() {
        var a = "." + $(this).attr("id");
        $(this).parents(".pacs").hide(),

        $(a).show()
    }),

    $(".already-user").on("click", function() {
        $(".create-user-block").hide(),

        $(".already-user-block").show()
    }),

    $(".create-user").on("click", function() {
        $(".already-user-block").hide(),

        $(".create-user-block").show()
    }),

    $(".no-modify").on("click", function() {
        $(".sucess-msg-wiz").hide(),

        $(".account-step-1-block").show()
    }),

    $(".account-step-1").on("click", function() {
        $(".account-step-1-block").hide(),

        $(".account-step-2-block").show()
    }),

    $("#forget-id").change(function() {
        $(".resetpwd").hide(),

        $("#" + $(this).val()).show()
    }),

    $(".debit-card").on("keyup", function() {
        this.value.length == this.maxLength && $(this).next(".debit-card").focus()
    }),

    $(".forget-email1").on("click", function() {
        $(".forget-email-block1").hide(),

        $(".forget-email-block2").show()
    }),

    $(".unfreeze input[type='radio']").click(function() {
        "pan" == $(this).val() ? ($(".pan").show(),

            $(".username").hide()) : ($(".username").show(),

            $(".pan").hide())
    }),

    $(".invest-down").on("click", function() {
        var a = $(this).next();
        $(".rea-mod-time").not(a).hide(), a.toggle()
    }),

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".invest-drop").length;
        b || $(".rea-mod-time").hide()
    }),

    $(".time-drop li a").on("click", function() {
        $(".invest-item-time").html($(this).closest("li").find(".invest-time").text()),

        $(".rea-mod-time").hide();
        var a = $(this).attr("title");
        $(".optDisContent").show(),

        $(".optDisContent ." + a).show().siblings().hide()
    }),

    $(".name-drop input[type='checkbox']").click(function() {
        c()
    }),

    $(".invest-drop-close").on("click", function() {
        $(".rea-mod-time").hide()
    }),

    $(".sort-name").on("click", function() {
        $(this).closest(".sort-by").find(".sort-list").toggle(),

        $(".sort-by").toggleClass("active")
    }),

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".sort-name").length;
        b || ($(".sort-list").hide(),

            $(".sort-by").removeClass("active"))
    }),

    $(".sort-list li a").on("click", function() {
        $(".sort-select-name").html($(this).text()), alert(g),

        $(".sort-list").hide(),

        $(".sort-by").removeClass("active")
    }),

    $(".add-wish-sel").on("click", function() {
        $(this).closest(".msg-select").find(".sort-list").toggle()
    }),

    $(".sel-compare-li li a").on("click", function() {
        $(".sel-compare").html($(this).text()), alert(g),

        $(".sort-list").hide(),

        $(".sort-by").removeClass("active")
    }),

    $(".wish-compare").on("click", function() {
        $(this).is(":checked") || ($(this).closest(".stock-sec").find(".sel-msg-fly").show(),

            $(this).parents(".stock-sec").find(".wishlist").addClass("wishwork"))
    }),

    $(".cart-list").on("click", ".wishwork", function() {
        $(this).closest(".stock-sec").find(".sel-msg-fly").hide(),

        $(this).closest(".stock-sec").find(".schesme-wish").show()
    }),

    $(".add-wish").on("click", function() {
        $(this).closest(".stock-sec").find(".schesme-wish").hide(),

        $(this).closest(".stock-sec").find(".wish-suces").show().delay(2e3).fadeOut(800)
    }),

    $(".cancel-wish").on("click", function() {
        $(this).closest(".stock-sec").find(".schesme-wish").hide()
    }),

    $(".wish-compare-in").on("click", function() {
        $(this).is(":checked") || ($(".sel-msg-fly-in").show(),

            $(this).parentsUntil("stock-details").find(".wishlist-in").addClass("wishwork"))
    }),

    $(".cart-list").on("click", ".wishwork", function() {
        $(".sel-msg-fly-in").hide(),

        $(".schesme-wish-in").show()
    }),

    $(".add-wish").on("click", function() {
        $(".schesme-wish-in").hide(),

        $(".wish-suces-in").show().delay(2e3).fadeOut(800)
    }),

    $(".cancel-wish-in").on("click", function() {
        $(".schesme-wish-in").hide()
    }),

    $(".filter-ele-close").on("click", function() {
        $(this).closest(".filter-box-name").hide()
    }),

    $(".acc-fill").click(function() {
        $(this).next(".fill-call-data").slideToggle("").siblings(".fill-call-data:visible").slideUp(""),

        $(this).toggleClass("current"),

        $(this).siblings(".acc-fill").removeClass("current")
    }),

    $(".list-ico").on("click", function() {
        $(".grid-ico").removeClass("active"),

        $(".grid-icon").removeClass("active"),

        $(".list-ico").addClass("active"),

        $(".list-icon").addClass("active"),

        $(".grid-box").addClass("list-box")
    }),

    $(".grid-ico").on("click", function() {
        $(".list-ico").removeClass("active"),

        $(".list-icon").removeClass("active"),

        $(".grid-ico").addClass("active"),

        $(".grid-icon").addClass("active"),

        $(".grid-box").removeClass("list-box")
    }),

    $(".cartmore").on("click", function() {
        $(this).closest(".cart-more-menu").find(".cart-more-items").toggle()
    }),

    $(document).click(function(a) {
        var b = $(a.target).closest(".cart-more-menu").length;
        b || $(".cart-more-items").hide()
    }),

    $(".cart-more-items li a").on("click", function() {
        $(".cart-more-items").hide()
    }), setTimeout(function() {
        $(".invest-drop").removeClass("coath-text"),

        $(".coatch-overlay").fadeOut(300),

        $(".coatch-overlay").css("display", "none") ? $("body").addClass("open") : $("body").removeClass("open")
    }, 5e3),

    $(document).click(function() {
        $(".invest-drop").removeClass("coath-text"),

        $(".coatch-overlay").fadeOut(300),

        $("body").css("overflow", "inherit")
    }),

    $(".rea-mod-time input[type='radio']").click(function() {
        var a = $('input[name="time"]:checked').val();
        $(".invest-items-time").text(a)
    }),

    $(".rea-mod-time input[type='checkbox']").click(function() {
        c()
    }),

    $(".res-moremenu").on("click", function() {
        $(".header-menu").toggle()
    });
    var d = $(document).width();
    995 >= d && $(document).click(function(a) {
        if ($(document).width() < 995) {
            console.log("getting RES_Moremenu", $(a.target).closest(".res-moremenu").length);
            var b = $(a.target).closest(".res-moremenu").length;
            0 == b && $(".header-menu").hide()
        }
    }), 995 >= d && $(document).click(function(a) {
        var b = $(a.target).closest(".res-moremenu, .header-menu").length;
        0 == b && $(".header-menu").hide()
    }),

    $(".fill-box,.fil-fly-btns").on("click", function() {
        $(".filter-content-box").slideToggle()
    }),

    $(document).on("click", function(a) {
        if ($(document).width() < 995) {
            var b = $(a.target).closest(".fill-box,.filter-content-box").length;
            0 == b && $(".filter-content-box").slideUp()
        }
    }),

    $(".sucess-alert-btn").on("click", function() {
        var a = $(".def-msg-none");
        $(".def-msg").hide(), a.is(":visible") || (a.show(), setTimeout(function() {
            a.hide()
        }, 2e3))
    }),

    $(".report-showall").on("click", function() {
        var a = $(this).next();
        $(".report-name-fly").not(a).hide(), a.toggle()
    }),

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".report-showall").length;
        b || $(".report-name-fly").hide()
    }),

    $(".desc-content").on("click", function() {
        var a = $(this).next();
        $(".report-content").not(a).hide(), a.toggle()
    }),

    $(document).on("click", function(a) {
        var b = $(a.target).closest(".desc-content").length;
        b || $(".report-content").hide()
    }),

    $(".jqpop").on("click", ".graph-dis", function() {
        $(".graph-deisgn,.ratle-btns").hide(),

        $(".graph-content,.grph-btns").show()
    }),

    $(".jqpop").on("click", ".content-dis", function() {
        $(".graph-content,.grph-btns").hide(),

        $(".graph-deisgn,.ratle-btns").show()
    });
    $(".sensex-list").newsTicker({
        row_height: 31,
        max_rows: 5,
        duration: 4e3
    });
    $(".pop-pack").on("click", ".showdetails", function() {
        $(".plandetails-show").show(),

        $(".showdetails").hide()
    }),

    $(".tabs").tabs(), tabslider(),

    $(".select").select2({
        minimumResultsForSearch: -1
    }), f(),

    $(".premiumresearchdialog,.pop-pack,.addtopopup").dialog({
        autoOpen: !1,
        draggable: !1,
        resizable: !1,
        modal: !0,
        autoReposition: !0,
        width: 450
    });
    var g = 1;
    $(window).resize(function() {
        f(), g++, console.log("Count i ", g),

        $(".premiumresearchdialog,.pop-pack,.addtopopup").dialog("option", "position", "center")
    }),

    $(".premiumresearchdialog,.pop-pack").dialog({
        width: 980
    }),

    $(".addtopopup").dialog({
        width: 800
    }),

    $(".checkpremium,.pop-like,.report-ful-desc,.basicCourse, .EventPlaceHolder .status").on("click", function() {
        $("body").toggleClass("popup-overflow");
        var a = $(this).attr("title");
        console.log("aaaa", a);
        $(".pop-pack").dialog("open").load(a + ".html")
    }),

    $(".jqpop").on("click", ".dialog-close", function(a) {
        return a.preventDefault(),
            $("body").removeClass("popup-overflow"),
            $(".pop-pack").dialog("close"), !1
    }),

    $(".courseEnable").on("click", function() {
        $(".viewDemo").slideUp(100);
        $(".takeACourse").slideToggle(800)
    }),

    $(".demoEnable").on("click", function() {
        $(".takeACourse").slideUp(100);
        $(".viewDemo").slideToggle(800);
    }),

    $(".optClose").on("click", function() {
        $(".takeACourse").slideUp(500)
    }),

    $(".learnCourseExpand").hide(),
    // $(".learnHolder").hide(),

    $(".pop-pack").on("click", ".learnCourseLoad", function() {
        $("body").removeClass("popup-overflow"),
        $(".pop-pack").dialog("close"),
        $(".learnHolder").hide(),
        $(".learnCourseExpand").show()
    });

    $('.goBack').on('click', function() {
        $(".takeACourse").slideUp()
        $(".learnHolder").show();
        $(".learnCourseExpand").hide()
    });

    var selectedList = $('.leftNavHolder .mainList li.active');
    var selVal = $(selectedList).attr('data-trig');
    $('.navItems ul').each(function(i, n) {
        $('.' + selVal).show().siblings().hide();
    });


    var lNav = $('.leftNavHolder .navHolder');

    $('.mainListHeading .topicHeading').text(selectedList.text());

    $('.navCtrl .goBack a').on('click', function() {
        $('.navItems').find('ul:first-child').show().siblings().hide();
        $('.navCtrl').hide();
    });

    $('.leftNavHolder .mainList li a').on('click', function(d) {
        var trigItem = $(d.target);
        var eleActive = trigItem.parent().attr('data-trig');
        $('.' + eleActive).show().siblings().hide();
        trigItem.parent().addClass('active').siblings().removeClass('active');
        $('.mainListHeading .topicHeading').text(trigItem.text());
        $('.navCtrl').show();
        $('.nextModule span').text(trigItem.parent().next().find('a').text());
        console.log("Lenght os sens", $('.nextModule span'));
    });

    $('.navItems ul:nth-child(n+2) li a').on('click', function() {
        $(this).closest('li').addClass('active').siblings().removeClass('active');
    });

    // QUIZ MODULE
    var totalQ = 5;
    var currentQ = 1;
    var quizObj = [{
        'q': "Increase in which of the following economic factors is good sign for the economy?",
        'a': 'b'
    }, {
        'q': "This is second question?",
        'a': 'c'
    }];

    var quizSel = $('.quizOptsSel li');
    var choose = 0;
    quizSel.on('click', function(e) {
        if (choose < 1) {
            var hitTar = e.target.nodeName;
            var selObj;
            switch (hitTar) {
                case 'LI':
                    selObj = $(e.target);
                    break;
                case 'B':
                    selObj = $(e.target).parent();
                    break;
                case 'SPAN':
                    selObj = $(e.target).parent();
                    break;
                default:
                    console.log("Select something");
                    break;
            }
            quizSel.each(function(i, n) {
                if ($(n).attr('data-opt') == quizObj[0].a) {
                    $(n).addClass('success').siblings().removeClass('success');
                }
            });

            if (selObj.attr('data-opt') == quizObj[0].a) {
                $(selObj.addClass('success').siblings().removeClass('success'));
                $('.quizHitResponse span.res').addClass('success').removeClass('failed');
                $('.quizHitResponse span.res').text("Yay that’s correct..");
            } else {
                $(selObj.addClass('failed').siblings().removeClass('failed'));
                $('.quizHitResponse span.res').addClass('failed').removeClass('success');
                $('.quizHitResponse span.res').text("Oops!! That’s incorrect");
            }
            choose++;
        }
    });

    $(document).ready(function() {
        var eventObj = $('.calenderHolder.learn table td.event');
        var eventEle = $('.EventPlaceHolder .day-event');

        eventEle.show();

        $('tbody.event-calendar td.event').on('click', function(e) {
            console.log("Clicked");
            $('.day-event').slideUp('fast');
            var monthEvent = $(this).attr('date-month');
            var dayEvent = $(this).text();
            // $('.day-event[date-month="' + monthEvent + '"][date-day="' + dayEvent + '"]').slideDown('fast');
            $('.day-event').slideDown('fast');

            eventEle.each(function() {
                $(this).show();
            });
        });

    });


    /*$(document).on('ready resize', function (e) {
        e.preventDefault();
        var courseHolder  = $('.site-start-modules-learn'),
            wh = $(window),
            lh = $('.leftNavHolder'),
            rh = $('.rightContentHolder'),
            headH = $('header .header-top-learn').height(),
            footH = $('footer.footer-learn').height(),
            rhCtrl = $('.rightContentPageCtrls').height(),
            rhInner = $('.rightcontentHolderInner'),
            sectionHolder = $('section.site-start-modules-learn'),
            bodyHeight = wh.height()-(headH+footH);
             

        console.log("HH", courseHolder.height(), wh.height(), lh.height(), rh.height(), headH, footH, rhCtrl);
        console.log("BB", bodyHeight);
        // lh.css({'height': bodyHeight});

        if(wh.width() < 995){
            sectionHolder.css({
                'position': 'fixed',
                'left': '-350px',
                'width': '1366px'
            });
            lh.css({
                // 'position': 'absolute',
                // 'width': '350px',
                // 'z-index': '9999'
            });
            rh.css({
                // 'position': 'absolute',
                'width': sectionHolder.width()-lh.width()-230
            });
            console.log('123', wh.width());
        }else{
            sectionHolder.removeAttr('style');
            lh.removeAttr('style');
            rh.removeAttr('style');
        }
    });
*/
    


    $(document).ready(function(){
        var boxWidth = $(".box").width();
        $(".slide-left").click(function(){
            $(".box").animate({
                width: 0
            });
        });
        $(".slide-right").click(function(){
            $(".box").animate({
                width: boxWidth
            });
        });
    });



    $('.EventPlaceHolder .status').on('click', function(e) {
        // console.log("This is ", $(e.target));
    });

});
var flag = 1;
$(window).resize(function() {
    if ($(document).width() < 995) {
        var graphHeight = $('.ui-slider-tabs-content-container').css('height', $('.mar-main').height());
        // console.log("Graph height", graphHeight);
    } else {
        var graphHeight = $('.ui-slider-tabs-content-container').css('height', $('.mar-main').height());
    }
    1 >= flag && (console.log("REsized", flag), flag++), navigation()

});